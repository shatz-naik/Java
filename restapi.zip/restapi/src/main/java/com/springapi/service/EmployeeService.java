package com.springapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springapi.entity.Employee;
import com.springapi.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository emprepo;
	
	public Employee saveEmployee(Employee emp)
	{
		return emprepo.save(emp);
	}
	
	
	public List<Employee> saveEmployees(List<Employee> emps)
	{
		return emprepo.saveAll(emps);
	}
	
	
	public String deleteEmployee(int id)
	{
        emprepo.deleteById(id);
        return "Employee removed !! " + id;
    }
	
	
	public Employee updateEmployee(Employee emp)
	{
		Employee existingemp = emprepo.findById(emp.getEmpId()).orElse(null);
		existingemp.setFirstName(emp.getFirstName());
		existingemp.setLastName(emp.getLastName());
		existingemp.setEmail(emp.getEmail());
		
		return emprepo.save(existingemp);
	}
	
	
	public Employee getEmployeeById(int empid)
	{
		return emprepo.findById(empid).orElse(null);
		
	}
}







